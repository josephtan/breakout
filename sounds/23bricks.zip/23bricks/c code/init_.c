#include "C:\EUPHORIA\include\euphoria.h"
#include "main_.h"

int _9;
int _10;
int _12;
int _26;
int _28;
int _29;
int _44;
int _164;
int _175;
int _216;
int _218;
int _226;
int _278;
int _286;
int _313;
int _314;
int _324;
int _344;
int _350;
int _354;
int _355;
int _362;
int _363;
int _364;
int _369;
int _380;
int _381;
int _382;
int _384;
int _385;
int _390;
int _393;
int _397;
int _398;
int _400;
int _402;
int _404;
int _405;
int _411;
int _412;
int _421;
int _423;
int _428;
int _429;
int _431;
int _440;

int _2DIGITS;
int _2HEX_DIGITS;
int _2START_NUMERIC;
int _2input_file;
int _2input_string;
int _2string_next;
int _2ch;
int _2ESCAPE_CHARS;
int _2ESCAPED_CHARS;
int _3pretty_end_col;
int _3pretty_chars;
int _3pretty_start_col;
int _3pretty_level;
int _3pretty_file;
int _3pretty_ascii;
int _3pretty_indent;
int _3pretty_ascii_min;
int _3pretty_ascii_max;
int _3pretty_line_count;
int _3pretty_line_max;
int _3pretty_dots;
int _3pretty_fp_format;
int _3pretty_int_format;
int _3pretty_line;
int _3PI;
int _3PI_HALF;
int _1bricks;
int _1players;
int _1line;
int _1take;
int _1lost;
int _1key;


struct routine_list _00[] = {
  {"", 0, 999999999, 0, 0, 0}
};

struct ns_list _01[] = {
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern double sqrt();
    _440 = NewString("Bye-bye.\n");
    _431 = NewString("Do you want to play again? Type Y for Yes or N for No.\n");
    _429 = NewString("Sorry, but you get the last brick and you lost.\n");
    _428 = NewString("Sorry player one you got the last brick and lost.\n");
    _423 = NewString("I take %d bricks leaving %d bricks.\n");
    _421 = NewString("How smart of me! I took the last brick. Okay so what, you beat me this time!.\n");
    _412 = NewString("Pass the keyboard or note-taker back to player one. Press any key to continue.\n");
    _411 = NewString("Sorry player two, you took the last brick and lost!\n");
    _390 = NewString("You take %d bricks leaving %d bricks.\n");
    _405 = NewString("\x01\x03");
    _404 = NewString("To repeat how many bricks are left again, press any other key.\n");
    _384 = NewString("How many bricks do you want? Choose 1, 2, or 3.\n");
    _402 = NewString("There are now %d bricks remaining.\n");
    _400 = NewString("Pass the keyboard or note-taker to player two. Press any key to continue.\n");
    _398 = NewString("All right! So you beat me this time.\n");
    _397 = NewString("Sorry player two you get the last brick and lose.\n");
    _393 = NewString("Sorry, you took the last brick and lost!\n");
    _385 = NewString("If you need the amount repeated again, press 0.\n");
    _382 = NewString("There are %d bricks remaining.\n");
    _381 = NewString("Your Turn.\n");
    _380 = NewString("Player one it is your turn.\n");
    _369 = NewString("Are you playing with someone else? Type Y for Yes or N for No.\n");
    _364 = NewString("Whoever takes the last brick loses!\n");
    _363 = NewString("You and another person, or the computer can take one, two, or three bricks.\n");
    _362 = NewString("You have a pile of twenty-three bricks.\n");
    _355 = NewString("Do you need instructions? Type Y for Yes or N for No.\n");
    _354 = NewString("Hi! Let's play a game of twenty-three bricks.\n");
    _350 = NewString("Too high enter a number from %d to %d.");
    _344 = NewString("Too low enter a number from %d to %d.");
    _324 = NewDouble((double)1.0000000000000000e+00);
    _314 = NewDouble((double)2.0000000000000000e+00);
    _313 = NewDouble((double)3.1415926535897931e+00);
    _44 = NewString("");
    _216 = NewString("%.10g");
    _286 = NewString("%d");
    _278 = NewString(" ...");
    _226 = NewString("}");
    _218 = NewString("{");
    _175 = NewString("A number from %g to %g is expected here - try again\n");
    _164 = NewString("A number is expected - try again\n");
    _29 = NewString("\n\t'\"\\\r");
    _28 = NewString("nt'\"\\r");
    _26 = NewString(" \t\n\r");
    _12 = NewString("-+.#");
    _10 = NewString("ABCDEF");
    _9 = NewString("0123456789");
}
