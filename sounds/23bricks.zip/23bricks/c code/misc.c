// Euphoria To C version 2.5
#include "C:\EUPHORIA\include\euphoria.h"
#include "main_.h"

int _3sleep(int _t)
{
    int _0, _1, _2;
    

    //     if t >= 0 then 

    // 	machine_proc(M_SLEEP, t) 
    machine(64, 1);
L1:

    // end procedure 
    return 0;
    ;
}


