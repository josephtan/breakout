// Euphoria To C version 2.5
#include <time.h>
#include "C:\EUPHORIA\include\euphoria.h"
#include <float.h>
#include "main_.h"

int Argc;
char **Argv;
unsigned default_heap;
__declspec(dllimport) unsigned __stdcall GetProcessHeap(void);
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;

void main(int argc, char *argv[])
{
    int _361 = 0;
    int _11 = 0;
    int _0, _1, _2;
    
    void *hInstance;
    
    hInstance = 0;
    _control87(MCW_EM,MCW_EM);
    default_heap = GetProcessHeap();
    Argc = argc;
    Argv = argv;
    winInstance = hInstance;
    eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)CLOCKS_PER_SEC);
    init_literal();
    shift_args(argc, argv);
    RefDS(_9);
    _2DIGITS = _9;
    Concat((object_ptr)&_2HEX_DIGITS, _2DIGITS, (s1_ptr)_10);
    Concat((object_ptr)&_2START_NUMERIC, _2DIGITS, (s1_ptr)_12);
    RefDS(_28);
    _2ESCAPE_CHARS = _28;
    RefDS(_29);
    _2ESCAPED_CHARS = _29;
    RefDS(_313);
    _3PI = _313;
    _3PI_HALF = NewDouble(DBL_PTR(_3PI)->dbl / DBL_PTR(_314)->dbl);

    // lost = 0 --Turn it off for now, no one lost. 
    _1lost = 0;

    // clear_screen() --Erase text off the screen. 
    ClearScreen();

    // puts(1, "Hi! Let's play a game of twenty-three bricks.\n") 
    EPuts(1, _354);

    // while 1 do --Start a loop until Y or N is pressed. 
L1:

    // puts(1, "Do you need instructions? Type Y for Yes or N for No.\n") 
    EPuts(1, _355);

    // key = wait_key() --Suspend execution until the user presses a key. 
    _0 = _2wait_key();
    _1key = _0;

    // if key = 'y' or key = 'Y' then --The user pressed Y, so print the instructions. 
    DeRef(_11);
    _11 = (_1key == 121);
    if (_11 != 0) {
        goto L2;
    }
    DeRef(_361);
    _361 = (_1key == 89);
L3:
    if (_361 == 0)
        goto L4;
L2:

    // clear_screen() --Erase text off of the screen. 
    ClearScreen();

    // puts(1, "You have a pile of twenty-three bricks.\n") 
    EPuts(1, _362);

    // puts(1, "You and another person, or the computer can take one, two, or three bricks.\n") 
    EPuts(1, _363);

    // puts(1, "Whoever takes the last brick loses!\n") 
    EPuts(1, _364);

    // exit --Get out of this loop to continue with the game. 
    goto L5;
    goto L1;
L4:

    // elsif key = 'n' or key = 'N' then --N was pressed, so get out of this loop to continue the game. 
    DeRef(_361);
    _361 = (_1key == 110);
    if (_361 != 0) {
        goto L5;
    }
    DeRef(_11);
    _11 = (_1key == 78);
L6:
    if (_11 == 0)
        goto L1;
L7:

    // exit 
    goto L5;
L8:
L9:

    // end while --The loop ends here. 
    goto L1;
L5:

    // while 1 do --This loop finds out if another person is playing, or is the computer playing. 
LA:

    // puts(1, "Are you playing with someone else? Type Y for Yes or N for No.\n") 
    EPuts(1, _369);

    // key = wait_key() --Suspend the program until the user presses a key. 
    _0 = _2wait_key();
    _1key = _0;

    // if key = 'y' or key = 'Y' then --Y was pressed, so they will be playing with someone else. 
    DeRef(_11);
    _11 = (_1key == 121);
    if (_11 != 0) {
        goto LB;
    }
    DeRef(_361);
    _361 = (_1key == 89);
LC:
    if (_361 == 0)
        goto LD;
LB:

    // players = 1 --Signify that someone else is playing by turning on this flag. 
    _1players = 1;

    // exit --Start the game. 
    goto LE;
    goto LA;
LD:

    // elsif key = 'n' or key = 'N' then --The user isn't playing with anyone else, so they will play with me. 
    DeRef(_361);
    _361 = (_1key == 110);
    if (_361 != 0) {
        goto LF;
    }
    DeRef(_11);
    _11 = (_1key == 78);
L10:
    if (_11 == 0)
        goto LA;
LF:

    // players = 0 --Signify this and turn this flag off. 
    _1players = 0;

    // exit --Start the game. 
    goto LE;
L11:
L12:

    // end while --The loop ends here. 
    goto LA;
LE:

    // bricks = 23 --Start with twenty-three bricks. 
    _1bricks = 23;

    // line = rand(2) --Who's going first? 
    _1line = good_rand() % ((unsigned)2) + 1;

    // while 1 do --Game's loop until the game aborts. 
L13:

    // while line = 1 do --Player one's turn. 
L14:
    if (_1line != 1)
        goto L15;

    // if players then --More than one player is playing. 
    if (_1players == 0)
        goto L16;

    // puts(1, "Player one it is your turn.\n") 
    EPuts(1, _380);
    goto L17;
L16:

    // puts(1, "Your Turn.\n") 
    EPuts(1, _381);
L17:

    // printf(1, "There are %d bricks remaining.\n", {bricks}) 
    _0 = _11;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1bricks;
    _11 = MAKE_SEQ(_1);
    DeRef(_0);
    EPrintf(1, _382, _11);

    // puts(1, "How many bricks do you want? Choose 1, 2, or 3.\n") 
    EPuts(1, _384);

    // puts(1, "If you need the amount repeated again, press 0.\n") 
    EPuts(1, _385);

    // take = prompt_number({0,3}) --Accept a number from 1 to 3. 
    DeRefDSi(_11);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 3;
    _11 = MAKE_SEQ(_1);
    RefDS(_11);
    _0 = _1prompt_number(_11);
    _1take = _0;

    // if take = 0 then --How many were there? Can you repeat that again? 
    if (_1take != 0)
        goto L18;
    goto L14;
L18:

    // bricks -= take --Subtract the bricks from the pile. 
    _1bricks = _1bricks - _1take;

    // printf(1, "You take %d bricks leaving %d bricks.\n", {take, bricks}) 
    DeRef(_11);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1take;
    ((int *)_2)[2] = _1bricks;
    _11 = MAKE_SEQ(_1);
    EPrintf(1, _390, _11);

    // if bricks <1 then --You lost! 
    if (_1bricks >= 1)
        goto L19;

    // lost = 1 --Someone lost! 
    _1lost = 1;

    // puts(1, "Sorry, you took the last brick and lost!\n") 
    EPuts(1, _393);

    // line = 3 --Jump to the last game-loop. 
    _1line = 3;

    // exit 
    goto L15;
L19:

    // line = 2 --Jump to the next while-loop. 
    _1line = 2;

    // exit 
    goto L15;
L1A:

    // end while --The loop ends here. 
    goto L14;
L15:

    // if bricks <2 and not lost then --Only one brick remains. 
    DeRef(_11);
    _11 = (_1bricks < 2);
    if (_11 == 0) {
        goto L1B;
    }
    DeRef(_361);
    _361 = (_1lost == 0);
L1C:
    if (_361 == 0)
        goto L1B;

    // lost = 1 
    _1lost = 1;

    // if players then --More than one person is playing. Let them know which player lost. 
    if (_1players == 0)
        goto L1D;

    // puts(1, "Sorry player two you get the last brick and lose.\n") 
    EPuts(1, _397);

    // line = 3 --Jump to the end of the game. 
    _1line = 3;
    goto L1E;
L1D:

    // puts(1, "All right! So you beat me this time.\n") 
    EPuts(1, _398);

    // line = 3 --Jump to the last part of the program. 
    _1line = 3;
L1E:
L1B:

    // while line = 2 do --Player two or the computer's turn. 
L1F:
    if (_1line != 2)
        goto L20;

    // if players then --It's player two's turn. 
    if (_1players == 0)
        goto L21;

    // puts(1, "Pass the keyboard or note-taker to player two. Press any key to continue.\n") 
    EPuts(1, _400);

    // key = wait_key() --Wait for the user to press a key. 
    _0 = _2wait_key();
    _1key = _0;

    // printf(1, "There are now %d bricks remaining.\n", {bricks}) 
    _0 = _361;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1bricks;
    _361 = MAKE_SEQ(_1);
    DeRef(_0);
    EPrintf(1, _402, _361);

    // puts(1, "How many bricks do you want? Choose 1, 2, or 3.\n") 
    EPuts(1, _384);

    // puts(1, "To repeat how many bricks are left again, press any other key.\n") 
    EPuts(1, _404);

    // take = prompt_number({1,3}) --Get a number from 1 to 3. 
    RefDS(_405);
    _0 = _1prompt_number(_405);
    _1take = _0;

    // if take = 0 then --What? How many were there? 
    if (_1take != 0)
        goto L22;
    goto L23;
L22:

    // bricks -= take --Subtract the requested number of bricks from the pile. 
    _1bricks = _1bricks - _1take;

    // printf(1, "You take %d bricks leaving %d bricks.\n", {take, bricks}) 
    DeRef(_361);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1take;
    ((int *)_2)[2] = _1bricks;
    _361 = MAKE_SEQ(_1);
    EPrintf(1, _390, _361);

    // if bricks <1 then --You lose! 
    if (_1bricks >= 1)
        goto L24;

    // lost = 1 
    _1lost = 1;

    // puts(1, "Sorry player two, you took the last brick and lost!\n") 
    EPuts(1, _411);

    // line = 3 --Jump to the last loop. 
    _1line = 3;

    // exit 
    goto L20;
L24:

    // line = 1 --Jump to the previous player's loop. 
    _1line = 1;

    // puts(1, "Pass the keyboard or note-taker back to player one. Press any key to continue.\n") 
    EPuts(1, _412);

    // key = wait_key() --Stop and wait for a keyboard response. 
    _0 = _2wait_key();
    _1key = _0;

    // exit 
    goto L20;
L23:
L21:

    // if bricks = 6 or bricks = 4 then --Cheat! 
    DeRef(_361);
    _361 = (_1bricks == 6);
    if (_361 != 0) {
        goto L25;
    }
    DeRef(_11);
    _11 = (_1bricks == 4);
L26:
    if (_11 == 0)
        goto L27;
L25:

    // take = 3 --Take three bricks. 
    _1take = 3;
    goto L28;
L27:

    // elsif bricks <= 3 then 
    if (_1bricks > 3)
        goto L29;

    // take = rand(2) 
    _1take = good_rand() % ((unsigned)2) + 1;
    goto L28;
L29:

    // take = rand(3) 
    _1take = good_rand() % ((unsigned)3) + 1;
L28:

    // if bricks <2 then 
    if (_1bricks >= 2)
        goto L2A;

    // lost = 1 
    _1lost = 1;

    // puts(1, "How smart of me! I took the last brick. Okay so what, you beat me this time!.\n") 
    EPuts(1, _421);

    // line = 3 --Jump to the last game-loop. 
    _1line = 3;

    // exit 
    goto L20;
L2A:

    // bricks -= take --Subtract the bricks the computer chose from the pile. 
    _1bricks = _1bricks - _1take;

    // printf(1, "I take %d bricks leaving %d bricks.\n", {take, bricks}) 
    DeRef(_11);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1take;
    ((int *)_2)[2] = _1bricks;
    _11 = MAKE_SEQ(_1);
    EPrintf(1, _423, _11);

    // line = 1 --Jump to the prior player's loop. 
    _1line = 1;

    // exit 
    goto L20;

    // end while --Playor two's and the computer's loop ends here. 
    goto L1F;
L20:

    // if bricks <2 and not lost then --Only one brick remains. 
    DeRef(_11);
    _11 = (_1bricks < 2);
    if (_11 == 0) {
        goto L2B;
    }
    DeRef(_361);
    _361 = (_1lost == 0);
L2C:
    if (_361 == 0)
        goto L2B;

    // line = 3 --Jump to the last part of the program. 
    _1line = 3;

    // if players then --Who lost? Be specific. 
    if (_1players == 0)
        goto L2D;

    // puts(1, "Sorry player one you got the last brick and lost.\n") 
    EPuts(1, _428);
    goto L2E;
L2D:

    // puts(1, "Sorry, but you get the last brick and you lost.\n") 
    EPuts(1, _429);
L2E:
L2B:

    // while line = 3 do --Ask if they want to play again. 
L2F:
    if (_1line != 3)
        goto L13;

    // puts(1, "Do you want to play again? Type Y for Yes or N for No.\n") 
    EPuts(1, _431);

    // key = wait_key() --Stop and let the user respond. 
    _0 = _2wait_key();
    _1key = _0;

    // if key = 'y' or key = 'Y' then --The user wants to play again. 
    DeRef(_361);
    _361 = (_1key == 121);
    if (_361 != 0) {
        goto L30;
    }
    DeRef(_11);
    _11 = (_1key == 89);
L31:
    if (_11 == 0)
        goto L32;
L30:

    // line = rand(2) --Who's going first? 
    _1line = good_rand() % ((unsigned)2) + 1;

    // bricks = 23 --Pile twenty-three bricks back on. 
    _1bricks = 23;

    // exit --Restart the game. 
    goto L13;
    goto L2F;
L32:

    // elsif key = 'n' or key = 'N' then --They don't want to play again. 
    DeRef(_11);
    _11 = (_1key == 110);
    if (_11 != 0) {
        goto L33;
    }
    DeRef(_361);
    _361 = (_1key == 78);
L34:
    if (_361 == 0)
        goto L2F;
L33:

    // puts(1, "Bye-bye.\n") 
    EPuts(1, _440);

    // sleep(1) --Suspend execution for one second. 
    _3sleep(1);

    // abort(0) --Abort with no error code. 
    UserCleanup(0);
L35:
L36:

    // end while 
    goto L2F;
L37:

    // end while 
    goto L13;
L38:
    Cleanup(0);
}
