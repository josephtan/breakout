// Euphoria To C version 2.5
#include "C:\EUPHORIA\include\euphoria.h"
#include "main_.h"

int _2wait_key()
{
    int _19;
    int _0, _1, _2;
    

    //     return machine_func(M_WAIT_KEY, 0) 
    _19 = machine(26, 0);
    return _19;
    ;
}


