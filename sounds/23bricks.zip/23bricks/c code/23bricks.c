// Euphoria To C version 2.5
#include "C:\EUPHORIA\include\euphoria.h"
#include "main_.h"

int _1prompt_number(int _number)
{
    int _key;
    int _340 = 0;
    int _346 = 0;
    int _0, _1, _2;
    

    // key = 0 
    _key = 0;

    // while 1 do --Get the user's input until it is correct. 
L1:

    // key = wait_key() --Wait for a keypress. 
    _key = _2wait_key();

    // key -= 48 --Subtract to get the correct ASCII value. 
    _key = _key - 48;

    // if key <number[1] then --Invalid. 
    DeRef(_340);
    _2 = (int)SEQ_PTR(_number);
    _340 = (int)*(((s1_ptr)_2)->base + 1);
    if (_key >= _340)
        goto L2;

    // printf(1, "Too low enter a number from %d to %d.", {number[1], number[2]}) 
    _2 = (int)SEQ_PTR(_number);
    _340 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_346);
    _2 = (int)SEQ_PTR(_number);
    _346 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _340;
    ((int *)_2)[2] = _346;
    _346 = MAKE_SEQ(_1);
    EPrintf(1, _344, _346);
    goto L1;
L2:

    // elsif key >number[2] then --Too high! 
    DeRef(_346);
    _2 = (int)SEQ_PTR(_number);
    _346 = (int)*(((s1_ptr)_2)->base + 2);
    if (_key <= _346)
        goto L3;

    // printf(1, "Too high enter a number from %d to %d.", {number[1], number[2]}) 
    _2 = (int)SEQ_PTR(_number);
    _346 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_340);
    _2 = (int)SEQ_PTR(_number);
    _340 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _346;
    ((int *)_2)[2] = _340;
    _340 = MAKE_SEQ(_1);
    EPrintf(1, _350, _340);
    goto L1;
L3:

    // return key --Give the value back to the program. 
    DeRefDSi(_number);
    DeRef(_340);
    DeRef(_346);
    return _key;
L4:

    // end while 
    goto L1;
L5:
    ;
}


